
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Generated from EDMX file: E:\Documents\Master\DAI\DAIApplication\DAIApplication.Data\Database\DbEntities.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [DAI-application];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK__QAnswer__Questio__5535A963]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QAnswer] DROP CONSTRAINT [FK__QAnswer__Questio__5535A963];
GO
IF OBJECT_ID(N'[dbo].[FK__Question__QTypeI__5070F446]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Question] DROP CONSTRAINT [FK__Question__QTypeI__5070F446];
GO
IF OBJECT_ID(N'[dbo].[FK__QuestionI__Quest__5EBF139D]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QuestionInTest] DROP CONSTRAINT [FK__QuestionI__Quest__5EBF139D];
GO
IF OBJECT_ID(N'[dbo].[FK__QuestionI__TestI__5DCAEF64]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[QuestionInTest] DROP CONSTRAINT [FK__QuestionI__TestI__5DCAEF64];
GO
IF OBJECT_ID(N'[dbo].[FK__Subcateg__QCate__4AB81AF0]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Subcategory] DROP CONSTRAINT [FK__Subcateg__QCate__4AB81AF0];
GO
IF OBJECT_ID(N'[dbo].[FK__Test__CategoryId__59FA5E80]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Test] DROP CONSTRAINT [FK__Test__CategoryId__59FA5E80];
GO
IF OBJECT_ID(N'[dbo].[FK__Test__Subcategor__5AEE82B9]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Test] DROP CONSTRAINT [FK__Test__Subcategor__5AEE82B9];
GO
IF OBJECT_ID(N'[dbo].[FK__Test__UserId__6D0D32F4]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Test] DROP CONSTRAINT [FK__Test__UserId__6D0D32F4];
GO
IF OBJECT_ID(N'[dbo].[FK__UserTest__TestId__628FA481]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserTest] DROP CONSTRAINT [FK__UserTest__TestId__628FA481];
GO
IF OBJECT_ID(N'[dbo].[FK__UserTest__UserId__6B24EA82]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[UserTest] DROP CONSTRAINT [FK__UserTest__UserId__6B24EA82];
GO
IF OBJECT_ID(N'[dbo].[FK_dbo_AspNetUserClaims_dbo_AspNetUsers_UserId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AspNetUserClaims] DROP CONSTRAINT [FK_dbo_AspNetUserClaims_dbo_AspNetUsers_UserId];
GO
IF OBJECT_ID(N'[dbo].[FK_dbo_AspNetUserLogins_dbo_AspNetUsers_UserId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AspNetUserLogins] DROP CONSTRAINT [FK_dbo_AspNetUserLogins_dbo_AspNetUsers_UserId];
GO
IF OBJECT_ID(N'[dbo].[FK_dbo_AspNetUserRoles_dbo_AspNetRoles_RoleId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AspNetUserRoles] DROP CONSTRAINT [FK_dbo_AspNetUserRoles_dbo_AspNetRoles_RoleId];
GO
IF OBJECT_ID(N'[dbo].[FK_dbo_AspNetUserRoles_dbo_AspNetUsers_UserId]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AspNetUserRoles] DROP CONSTRAINT [FK_dbo_AspNetUserRoles_dbo_AspNetUsers_UserId];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[__MigrationHistory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[__MigrationHistory];
GO
IF OBJECT_ID(N'[dbo].[AspNetRoles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AspNetRoles];
GO
IF OBJECT_ID(N'[dbo].[AspNetUserClaims]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AspNetUserClaims];
GO
IF OBJECT_ID(N'[dbo].[AspNetUserLogins]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AspNetUserLogins];
GO
IF OBJECT_ID(N'[dbo].[AspNetUserRoles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AspNetUserRoles];
GO
IF OBJECT_ID(N'[dbo].[AspNetUsers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AspNetUsers];
GO
IF OBJECT_ID(N'[dbo].[Category]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Category];
GO
IF OBJECT_ID(N'[dbo].[QAnswer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[QAnswer];
GO
IF OBJECT_ID(N'[dbo].[QType]', 'U') IS NOT NULL
    DROP TABLE [dbo].[QType];
GO
IF OBJECT_ID(N'[dbo].[Question]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Question];
GO
IF OBJECT_ID(N'[dbo].[QuestionInTest]', 'U') IS NOT NULL
    DROP TABLE [dbo].[QuestionInTest];
GO
IF OBJECT_ID(N'[dbo].[Subcategory]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Subcategory];
GO
IF OBJECT_ID(N'[dbo].[Test]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Test];
GO
IF OBJECT_ID(N'[dbo].[UserProfile]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserProfile];
GO
IF OBJECT_ID(N'[dbo].[UserTest]', 'U') IS NOT NULL
    DROP TABLE [dbo].[UserTest];
GO
IF OBJECT_ID(N'[ModelStoreContainer].[database_firewall_rules]', 'U') IS NOT NULL
    DROP TABLE [ModelStoreContainer].[database_firewall_rules];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'C__MigrationHistory'
CREATE TABLE [dbo].[C__MigrationHistory] (
    [MigrationId] nvarchar(150)  NOT NULL,
    [ContextKey] nvarchar(300)  NOT NULL,
    [Model] varbinary(max)  NOT NULL,
    [ProductVersion] nvarchar(32)  NOT NULL
);
GO

-- Creating table 'AspNetRoles'
CREATE TABLE [dbo].[AspNetRoles] (
    [Id] nvarchar(128)  NOT NULL,
    [Name] nvarchar(256)  NOT NULL
);
GO

-- Creating table 'AspNetUserClaims'
CREATE TABLE [dbo].[AspNetUserClaims] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [UserId] nvarchar(128)  NOT NULL,
    [ClaimType] nvarchar(max)  NULL,
    [ClaimValue] nvarchar(max)  NULL
);
GO

-- Creating table 'AspNetUserLogins'
CREATE TABLE [dbo].[AspNetUserLogins] (
    [LoginProvider] nvarchar(128)  NOT NULL,
    [ProviderKey] nvarchar(128)  NOT NULL,
    [UserId] nvarchar(128)  NOT NULL
);
GO

-- Creating table 'AspNetUsers'
CREATE TABLE [dbo].[AspNetUsers] (
    [Id] nvarchar(128)  NOT NULL,
    [Email] nvarchar(256)  NULL,
    [EmailConfirmed] bit  NOT NULL,
    [PasswordHash] nvarchar(max)  NULL,
    [SecurityStamp] nvarchar(max)  NULL,
    [PhoneNumber] nvarchar(max)  NULL,
    [PhoneNumberConfirmed] bit  NOT NULL,
    [TwoFactorEnabled] bit  NOT NULL,
    [LockoutEndDateUtc] datetime  NULL,
    [LockoutEnabled] bit  NOT NULL,
    [AccessFailedCount] int  NOT NULL,
    [UserName] nvarchar(256)  NOT NULL
);
GO

-- Creating table 'Categories'
CREATE TABLE [dbo].[Categories] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(255)  NOT NULL
);
GO

-- Creating table 'QAnswers'
CREATE TABLE [dbo].[QAnswers] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [QuestionId] int  NOT NULL,
    [Answer] varchar(255)  NOT NULL,
    [Correct] bit  NOT NULL
);
GO

-- Creating table 'QTypes'
CREATE TABLE [dbo].[QTypes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(255)  NOT NULL
);
GO

-- Creating table 'Questions'
CREATE TABLE [dbo].[Questions] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [QTypeId] int  NOT NULL,
    [Text] varchar(max)  NULL
);
GO

-- Creating table 'QuestionInTests'
CREATE TABLE [dbo].[QuestionInTests] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [TestId] int  NOT NULL,
    [QuestionId] int  NOT NULL
);
GO

-- Creating table 'Subcategories'
CREATE TABLE [dbo].[Subcategories] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [CategoryId] int  NOT NULL,
    [Name] varchar(255)  NOT NULL
);
GO

-- Creating table 'Tests'
CREATE TABLE [dbo].[Tests] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [UserId] varchar(255)  NOT NULL,
    [Name] varchar(255)  NOT NULL,
    [CategoryId] int  NULL,
    [SubcategoryId] int  NULL,
    [Time] int  NULL,
    [Timestamp] datetime  NULL
);
GO

-- Creating table 'UserProfiles'
CREATE TABLE [dbo].[UserProfiles] (
    [UserId] varchar(255)  NOT NULL,
    [Username] varchar(255)  NOT NULL,
    [FirstName] varchar(255)  NULL,
    [LastName] varchar(255)  NULL,
    [Email] varchar(255)  NOT NULL,
    [PhoneNo] varchar(255)  NULL,
    [Country] varchar(255)  NULL,
    [Sex] varchar(255)  NULL
);
GO

-- Creating table 'UserTests'
CREATE TABLE [dbo].[UserTests] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [UserId] varchar(255)  NOT NULL,
    [TestId] int  NOT NULL,
    [Score] int  NOT NULL,
    [Time] int  NULL,
    [MaxScore] int  NOT NULL,
    [Timestamp] datetime  NULL
);
GO

-- Creating table 'database_firewall_rules'
CREATE TABLE [dbo].[database_firewall_rules] (
    [id] int IDENTITY(1,1) NOT NULL,
    [name] nvarchar(128)  NOT NULL,
    [start_ip_address] varchar(45)  NOT NULL,
    [end_ip_address] varchar(45)  NOT NULL,
    [create_date] datetime  NOT NULL,
    [modify_date] datetime  NOT NULL
);
GO

-- Creating table 'AspNetUserRoles'
CREATE TABLE [dbo].[AspNetUserRoles] (
    [AspNetRoles_Id] nvarchar(128)  NOT NULL,
    [AspNetUsers_Id] nvarchar(128)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [MigrationId], [ContextKey] in table 'C__MigrationHistory'
ALTER TABLE [dbo].[C__MigrationHistory]
ADD CONSTRAINT [PK_C__MigrationHistory]
    PRIMARY KEY CLUSTERED ([MigrationId], [ContextKey] ASC);
GO

-- Creating primary key on [Id] in table 'AspNetRoles'
ALTER TABLE [dbo].[AspNetRoles]
ADD CONSTRAINT [PK_AspNetRoles]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'AspNetUserClaims'
ALTER TABLE [dbo].[AspNetUserClaims]
ADD CONSTRAINT [PK_AspNetUserClaims]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [LoginProvider], [ProviderKey], [UserId] in table 'AspNetUserLogins'
ALTER TABLE [dbo].[AspNetUserLogins]
ADD CONSTRAINT [PK_AspNetUserLogins]
    PRIMARY KEY CLUSTERED ([LoginProvider], [ProviderKey], [UserId] ASC);
GO

-- Creating primary key on [Id] in table 'AspNetUsers'
ALTER TABLE [dbo].[AspNetUsers]
ADD CONSTRAINT [PK_AspNetUsers]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Categories'
ALTER TABLE [dbo].[Categories]
ADD CONSTRAINT [PK_Categories]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'QAnswers'
ALTER TABLE [dbo].[QAnswers]
ADD CONSTRAINT [PK_QAnswers]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'QTypes'
ALTER TABLE [dbo].[QTypes]
ADD CONSTRAINT [PK_QTypes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Questions'
ALTER TABLE [dbo].[Questions]
ADD CONSTRAINT [PK_Questions]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'QuestionInTests'
ALTER TABLE [dbo].[QuestionInTests]
ADD CONSTRAINT [PK_QuestionInTests]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Subcategories'
ALTER TABLE [dbo].[Subcategories]
ADD CONSTRAINT [PK_Subcategories]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Tests'
ALTER TABLE [dbo].[Tests]
ADD CONSTRAINT [PK_Tests]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [UserId] in table 'UserProfiles'
ALTER TABLE [dbo].[UserProfiles]
ADD CONSTRAINT [PK_UserProfiles]
    PRIMARY KEY CLUSTERED ([UserId] ASC);
GO

-- Creating primary key on [Id] in table 'UserTests'
ALTER TABLE [dbo].[UserTests]
ADD CONSTRAINT [PK_UserTests]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [id], [name], [start_ip_address], [end_ip_address], [create_date], [modify_date] in table 'database_firewall_rules'
ALTER TABLE [dbo].[database_firewall_rules]
ADD CONSTRAINT [PK_database_firewall_rules]
    PRIMARY KEY CLUSTERED ([id], [name], [start_ip_address], [end_ip_address], [create_date], [modify_date] ASC);
GO

-- Creating primary key on [AspNetRoles_Id], [AspNetUsers_Id] in table 'AspNetUserRoles'
ALTER TABLE [dbo].[AspNetUserRoles]
ADD CONSTRAINT [PK_AspNetUserRoles]
    PRIMARY KEY CLUSTERED ([AspNetRoles_Id], [AspNetUsers_Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [UserId] in table 'AspNetUserClaims'
ALTER TABLE [dbo].[AspNetUserClaims]
ADD CONSTRAINT [FK_dbo_AspNetUserClaims_dbo_AspNetUsers_UserId]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[AspNetUsers]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_dbo_AspNetUserClaims_dbo_AspNetUsers_UserId'
CREATE INDEX [IX_FK_dbo_AspNetUserClaims_dbo_AspNetUsers_UserId]
ON [dbo].[AspNetUserClaims]
    ([UserId]);
GO

-- Creating foreign key on [UserId] in table 'AspNetUserLogins'
ALTER TABLE [dbo].[AspNetUserLogins]
ADD CONSTRAINT [FK_dbo_AspNetUserLogins_dbo_AspNetUsers_UserId]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[AspNetUsers]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_dbo_AspNetUserLogins_dbo_AspNetUsers_UserId'
CREATE INDEX [IX_FK_dbo_AspNetUserLogins_dbo_AspNetUsers_UserId]
ON [dbo].[AspNetUserLogins]
    ([UserId]);
GO

-- Creating foreign key on [CategoryId] in table 'Subcategories'
ALTER TABLE [dbo].[Subcategories]
ADD CONSTRAINT [FK__Subcateg__QCate__4AB81AF0]
    FOREIGN KEY ([CategoryId])
    REFERENCES [dbo].[Categories]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__Subcateg__QCate__4AB81AF0'
CREATE INDEX [IX_FK__Subcateg__QCate__4AB81AF0]
ON [dbo].[Subcategories]
    ([CategoryId]);
GO

-- Creating foreign key on [CategoryId] in table 'Tests'
ALTER TABLE [dbo].[Tests]
ADD CONSTRAINT [FK__Test__CategoryId__59FA5E80]
    FOREIGN KEY ([CategoryId])
    REFERENCES [dbo].[Categories]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__Test__CategoryId__59FA5E80'
CREATE INDEX [IX_FK__Test__CategoryId__59FA5E80]
ON [dbo].[Tests]
    ([CategoryId]);
GO

-- Creating foreign key on [QuestionId] in table 'QAnswers'
ALTER TABLE [dbo].[QAnswers]
ADD CONSTRAINT [FK__QAnswer__Questio__5535A963]
    FOREIGN KEY ([QuestionId])
    REFERENCES [dbo].[Questions]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__QAnswer__Questio__5535A963'
CREATE INDEX [IX_FK__QAnswer__Questio__5535A963]
ON [dbo].[QAnswers]
    ([QuestionId]);
GO

-- Creating foreign key on [QTypeId] in table 'Questions'
ALTER TABLE [dbo].[Questions]
ADD CONSTRAINT [FK__Question__QTypeI__5070F446]
    FOREIGN KEY ([QTypeId])
    REFERENCES [dbo].[QTypes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__Question__QTypeI__5070F446'
CREATE INDEX [IX_FK__Question__QTypeI__5070F446]
ON [dbo].[Questions]
    ([QTypeId]);
GO

-- Creating foreign key on [QuestionId] in table 'QuestionInTests'
ALTER TABLE [dbo].[QuestionInTests]
ADD CONSTRAINT [FK__QuestionI__Quest__5EBF139D]
    FOREIGN KEY ([QuestionId])
    REFERENCES [dbo].[Questions]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__QuestionI__Quest__5EBF139D'
CREATE INDEX [IX_FK__QuestionI__Quest__5EBF139D]
ON [dbo].[QuestionInTests]
    ([QuestionId]);
GO

-- Creating foreign key on [TestId] in table 'QuestionInTests'
ALTER TABLE [dbo].[QuestionInTests]
ADD CONSTRAINT [FK__QuestionI__TestI__5DCAEF64]
    FOREIGN KEY ([TestId])
    REFERENCES [dbo].[Tests]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__QuestionI__TestI__5DCAEF64'
CREATE INDEX [IX_FK__QuestionI__TestI__5DCAEF64]
ON [dbo].[QuestionInTests]
    ([TestId]);
GO

-- Creating foreign key on [SubcategoryId] in table 'Tests'
ALTER TABLE [dbo].[Tests]
ADD CONSTRAINT [FK__Test__Subcategor__5AEE82B9]
    FOREIGN KEY ([SubcategoryId])
    REFERENCES [dbo].[Subcategories]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__Test__Subcategor__5AEE82B9'
CREATE INDEX [IX_FK__Test__Subcategor__5AEE82B9]
ON [dbo].[Tests]
    ([SubcategoryId]);
GO

-- Creating foreign key on [UserId] in table 'Tests'
ALTER TABLE [dbo].[Tests]
ADD CONSTRAINT [FK__Test__UserId__6D0D32F4]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserProfiles]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__Test__UserId__6D0D32F4'
CREATE INDEX [IX_FK__Test__UserId__6D0D32F4]
ON [dbo].[Tests]
    ([UserId]);
GO

-- Creating foreign key on [TestId] in table 'UserTests'
ALTER TABLE [dbo].[UserTests]
ADD CONSTRAINT [FK__UserTest__TestId__628FA481]
    FOREIGN KEY ([TestId])
    REFERENCES [dbo].[Tests]
        ([Id])
    ON DELETE CASCADE ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__UserTest__TestId__628FA481'
CREATE INDEX [IX_FK__UserTest__TestId__628FA481]
ON [dbo].[UserTests]
    ([TestId]);
GO

-- Creating foreign key on [UserId] in table 'UserTests'
ALTER TABLE [dbo].[UserTests]
ADD CONSTRAINT [FK__UserTest__UserId__6B24EA82]
    FOREIGN KEY ([UserId])
    REFERENCES [dbo].[UserProfiles]
        ([UserId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK__UserTest__UserId__6B24EA82'
CREATE INDEX [IX_FK__UserTest__UserId__6B24EA82]
ON [dbo].[UserTests]
    ([UserId]);
GO

-- Creating foreign key on [AspNetRoles_Id] in table 'AspNetUserRoles'
ALTER TABLE [dbo].[AspNetUserRoles]
ADD CONSTRAINT [FK_AspNetUserRoles_AspNetRole]
    FOREIGN KEY ([AspNetRoles_Id])
    REFERENCES [dbo].[AspNetRoles]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [AspNetUsers_Id] in table 'AspNetUserRoles'
ALTER TABLE [dbo].[AspNetUserRoles]
ADD CONSTRAINT [FK_AspNetUserRoles_AspNetUser]
    FOREIGN KEY ([AspNetUsers_Id])
    REFERENCES [dbo].[AspNetUsers]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AspNetUserRoles_AspNetUser'
CREATE INDEX [IX_FK_AspNetUserRoles_AspNetUser]
ON [dbo].[AspNetUserRoles]
    ([AspNetUsers_Id]);
GO

-- Populate Database

-- User Roles 
INSERT INTO AspNetRoles (Name) VALUES ('Admin');
INSERT INTO AspNetRoles (Name) VALUES ('User');

-- QTypes

INSERT INTO QType (Name) VALUES ('Single Answer');
INSERT INTO QType (Name) VALUES ('Multiple Answers');

-- Category

INSERT INTO Category (Name) VALUES ('Programming Language');
INSERT INTO Category (Name) VALUES ('Language');
INSERT INTO Category (Name) VALUES ('Logic');

-- Subcategory

INSERT INTO Subcategory (CategoryId, Name) VALUES (1, 'Java');
INSERT INTO Subcategory (CategoryId, Name) VALUES (1, 'C#');
INSERT INTO Subcategory (CategoryId, Name) VALUES (1, 'Python');
INSERT INTO Subcategory (CategoryId, Name) VALUES (1, 'Javascript');

INSERT INTO Subcategory (CategoryId, Name) VALUES (2, 'English');
INSERT INTO Subcategory (CategoryId, Name) VALUES (2, 'French');
INSERT INTO Subcategory (CategoryId, Name) VALUES (2, 'German');
INSERT INTO Subcategory (CategoryId, Name) VALUES (2, 'Spanish');

INSERT INTO Subcategory (CategoryId, Name) VALUES (3, 'Number Series');
INSERT INTO Subcategory (CategoryId, Name) VALUES (3, 'Verbal Classification');
INSERT INTO Subcategory (CategoryId, Name) VALUES (3, 'Analogies');
INSERT INTO Subcategory (CategoryId, Name) VALUES (3, 'Logical Problems');

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------